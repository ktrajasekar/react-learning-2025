export default function Footer() {
    return (
        <footer>
            <p>© 2023 My Website</p>
        </footer>
    );
}