import { NextRequest, NextResponse } from 'next/server';

// GET: Fetch a single post by ID
export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
    try {
        const res = await fetch(`https://dummyjson.com/posts/${params.id}`, {
            next: { revalidate: 3600 },
        });
        if (!res.ok) {
            return NextResponse.json({ error: 'Post not found' }, { status: 404 });
        }
        const post = await res.json();
        return NextResponse.json(post, { status: 200 });
    } catch (error) {
        return NextResponse.json({ error: 'Server error' }, { status: 500 });
    }
}